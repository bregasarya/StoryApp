package com.example.storyapp.remote.respone

data class AddNewStoryResponse(
	val error: Boolean,
	val message: String
)


