package com.example.storyapp.util

class Constant {
    companion object{
        const val BASE_URL= "https://story-api.dicoding.dev/v1/"
        const val EXTRA_ID = "extra id"
    }
}